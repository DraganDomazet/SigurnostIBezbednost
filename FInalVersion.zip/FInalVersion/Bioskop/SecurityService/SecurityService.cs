﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using System.Security.Permissions;
using System.Diagnostics;
using System.Security.Principal;
using System.DirectoryServices;
using System.DirectoryServices.ActiveDirectory;
using System.DirectoryServices.AccountManagement;
using System.Collections;
using System.Runtime.Serialization;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.Linq;
using SecurityManager;

namespace SecurityService
{
    public class SecurityService : IService
    {
        public static Dictionary<string, int> rezervacije = new Dictionary<string, int>();
        
     
        public class Entry
        {
            public string UserName;
            public string Pass;
            public int Rezervacije;

            public Entry()
            {
            }

            public Entry(string user, string pass, int rez)
            {
                UserName = user;
                Pass = pass;
                Rezervacije = rez;
            }
        }
        
        



        [PrincipalPermission(SecurityAction.Demand, Role = "Administrators")]
        public void AddUser(string username, string password)
        {

            Audit.AccessGranted(Environment.UserName, "Add");
            try
                {

                    DirectoryEntry AD = new DirectoryEntry("WinNT://" + Environment.MachineName + ",computer");
                    DirectoryEntry NewUser;
                    NewUser = AD.Children.Add(username, "user");
                    NewUser.Invoke("SetPassword", new object[] { password });
                    NewUser.Invoke("Put", new object[] { "Description", "Test User from .NET" });
                    NewUser.CommitChanges();

                
                   


                    DirectoryEntry grp;
                    grp = AD.Children.Find("korisnici", "group");
                    if (grp != null) { grp.Invoke("Add", new object[] { NewUser.Path.ToString() }); }
                    grp.Invoke("Put", new object[] { "Description", "Test Group User from .NET" });

                    grp.CommitChanges();
                    Console.WriteLine("Account Created Successfully");

                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message);
                    Console.ReadLine();
                }
                        
        }

        [PrincipalPermission(SecurityAction.Demand, Role = "Administrators")]
        public void RemoveUser(string username)
        {

            try
            {
                DirectoryEntry AD = new DirectoryEntry("WinNT://" + Environment.MachineName + ",computer");
                DirectoryEntry NewUser = AD.Children.Find(username, "user");
                AD.Children.Remove(NewUser);
                Console.WriteLine("Account Deleted Successfully");
                

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();

            }

        }

        public void AskForVip(string user, string sifra)
        {
            ArrayList myGroups = GetGroupMembers("korisnici");

            if (myGroups.Contains(user))
            {
                Audit.AccessGranted(user, "AskForVIP");
                using (FileStream aFile = new FileStream("d:\\demands.txt", FileMode.Append, FileAccess.Write))
                {
                    using (StreamWriter sw = new StreamWriter(aFile))
                    {
                        sw.WriteLine(user);
                        sw.WriteLine(sifra);
                        sw.WriteLine(rezervacije[user]);

                    }
                }
            }
            else
            {
                Audit.AccessDenied(user, "AskForVip");
                Console.WriteLine("User is not member of group korisnici");
            }

        }

        [PrincipalPermission(SecurityAction.Demand, Role = "Administrators")]
        public void DodajVip()
        {
            Audit.AccessGranted(Environment.UserName, "DodajVIP");

            var lines = File.ReadAllLines("d:\\demands.txt");
            Entry ent = new Entry();

            for (var j = 0; j < lines.Length;)
            {

                ent.UserName = (string)lines[j];
                ent.Pass = (string)lines[j + 1];
                ent.Rezervacije = Convert.ToInt32(lines[j + 2]);
                if (ent.Rezervacije > 9)
                {
                    AddUserToVIPs(ent.UserName, ent.Pass);
                    using (FileStream aFile = new FileStream("d:\\VIP.txt", FileMode.Append, FileAccess.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(aFile))
                        {
                            sw.WriteLine("VIP kartica");
                            sw.WriteLine("Clan: {0}\n", ent.UserName);
                            sw.WriteLine("Time: {0}", DateTime.Now);
                        }
                    }
                }
                else
                {
                    Console.WriteLine("User {0} can not become member of VIPs becose of insufficient number of reservations!", ent.UserName);
                }
                j += 3;

            }
           

        }

      
        public void AddUserToVIPs(string username, string password)
        {

            try
            {

                DirectoryEntry AD = new DirectoryEntry("WinNT://" + Environment.MachineName + ",computer");
                DirectoryEntry NewUser;
                NewUser = AD.Children.Add(username, "user");
                NewUser.Invoke("SetPassword", new object[] { password });
                NewUser.Invoke("Put", new object[] { "Description", "Test User from .NET" });
         
                

                DirectoryEntry grp;
                grp = AD.Children.Find("VIPs", "group");
                if (grp != null) { grp.Invoke("Add", new object[] { NewUser.Path.ToString() }); }
               

                grp.CommitChanges();
                Console.WriteLine("User added to group VIPs!");

            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }


        }
        public void AskForRemoval(string user)
        {

            ArrayList myGroups = GetGroupMembers("VIPs");

            if (myGroups.Contains(user))
            {
                Audit.AccessGranted(user, "AskForRemoval");
                using (FileStream aFile = new FileStream("d:\\remove.txt", FileMode.Append, FileAccess.Write))
                {
                    using (StreamWriter sw = new StreamWriter(aFile))
                    {
                        sw.WriteLine(user);
                    }
                }
            }
            else
            {
                Audit.AccessDenied(user, "AskForRemoval");
            }

        }

        [PrincipalPermission(SecurityAction.Demand, Role = "Administrators")]
        public void RemoveVip()
        {
           
            var lines = File.ReadAllLines("d:\\remove.txt");
            Entry ent = new Entry();

            for (var j = 0; j < lines.Length;)
            {

                ent.UserName = (string)lines[j];
                
                
                    RemoveUserFromVIPs(ent.UserName);
                    using (FileStream aFile = new FileStream("d:\\VIP.txt", FileMode.Append, FileAccess.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(aFile))
                        {
                            sw.WriteLine("User {0} is removed from group VIPs\n", ent.UserName);
                        }
                    }                
               
                j += 1;

            }
           

        }

        public void RemoveUserFromVIPs(string username)
        {

            try
            {
                DirectoryEntry AD = new DirectoryEntry("WinNT://" + Environment.MachineName + ",computer");
                DirectoryEntry grp;
                DirectoryEntry NewUser = AD.Children.Find(username, "user");

                grp = AD.Children.Find("VIPs", "group");
                if (grp != null) { grp.Invoke("Remove", new object[] { NewUser.Path.ToString() }); }
                
                grp.CommitChanges();
                
                

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();

            }


        }





        

        Projection p1 = new Projection("film1", 50);

        
       
        public void Reserve(int number, string kor)
        {
            Users u1 = new Users(kor);
            

            if (number > p1.BrojSedista)
            {
                Console.WriteLine("Nema dovoljno slobodnih sedista!");
            }
            else
            {
                p1.BrojSedista -= number;

                if (u1.Money < p1.Price * number)
                {
                    Console.WriteLine("Korisnik nema dovoljno novca na racunu!");
                }
                else
                {
                    u1.Money = u1.Money - (p1.Price * number);

                    ArrayList myGroups = GetGroupMembers("korisnici");
                    
                    if (myGroups.Contains(kor))
                    {
                        Audit.AccessGranted(kor, "Reserve");
                        {
                            foreach (var item in rezervacije.ToList())
                            {
                                if (item.Key.Contains(kor))
                                {
                                    rezervacije[kor] += number;

                                }
                            }

                            if (!rezervacije.Keys.Contains(kor))
                            {

                                rezervacije.Add(kor, number);
                                
                            }
                        }
                    }
                    else
                    {
                        Audit.AccessDenied(kor, "Reserve");
                    }

                    Console.WriteLine("Korisnik {0} je rezervisao {1} mesta za projekciju {2}", kor, rezervacije[kor], p1.Movie);
                }
            }
        }

       

        public void ReserveVIPs(int number, string kor)
        {

            Users u2 = new Users(kor);

            if (number < p1.BrojVIPSedista)
            {
                p1.BrojVIPSedista -= number;

                if (u2.Money < p1.Price * number)
                {
                    Console.WriteLine("Korisnik nema dovoljno novca na racunu!");
                }
                else
                {
                    u2.Money = u2.Money - (p1.Price * number);

                    ArrayList myGroups = GetGroupMembers("VIPs");

                    if (myGroups.Contains(kor))
                    {
                        Audit.AccessGranted(kor, "ReserveVIPs");
                        {
                            foreach (var item in rezervacije.ToList())
                            {
                                if (item.Key.Contains(kor))
                                {
                                    rezervacije[kor] += number;
                                    Console.WriteLine("User {0} has reserved {1} seats", Environment.UserName, rezervacije[kor]);
                                }
                            }

                            if (!rezervacije.Keys.Contains(kor))
                            {
                                rezervacije.Add(kor, number);
                                Console.WriteLine("User {0} has reserved {1} seats", Environment.UserName, rezervacije[kor]);
                            }
                        }
                    }
                    else
                    {
                        Audit.AccessDenied(kor, "ReserveVIPS");
                    }
                }

            }

            else if (number > p1.BrojSedista)
            {
                Console.WriteLine("Nema dovoljno slobodnih sedista!");
            }
            else
            {
                if (u2.Money < p1.Price * number)
                {
                    Console.WriteLine("Korisnik nema dovoljno novca na racunu!");
                }
                else
                {
                    Console.WriteLine("There is not enough VIP seats!");
                    p1.BrojSedista -= number;
                    if (u2.Money < p1.Price * number)
                    {
                        Console.WriteLine("Korisnik nema dovoljno novca na racunu!");
                    }
                    else
                    {
                        u2.Money = u2.Money - (p1.Price * number);

                        ArrayList myGroups = GetGroupMembers("korisnici");
                        
                        if (myGroups.Contains(kor))
                        {
                            Audit.AccessGranted(kor, "ReserveVIPs");
                            {
                                foreach (var item in rezervacije.ToList())
                                {
                                    if (item.Key.Contains(kor))
                                    {
                                        rezervacije[kor] += number;
                                    }
                                }

                                if (!rezervacije.Keys.Contains(kor))
                                {
                                    rezervacije.Add(kor, number);
                                }
                            }
                        }

                        else
                        {
                            Audit.AccessDenied(kor, "ReserveVIPs");
                        }

                        Console.WriteLine("VIPs member {0} reserved  {1} ordinary seats", Environment.UserName, rezervacije[kor]);
                    }
                }
            }
            
        }

        [PrincipalPermission(SecurityAction.Demand, Role = "Administrators")]
        public void AddReservation(string name, int number)
        {
            Users u2 = new Users(name);

            if (number < p1.BrojSedista)
            {
                p1.BrojVIPSedista -= number;
                u2.Money = u2.Money - (p1.Price * number);



                foreach (var item in rezervacije.ToList())
                {
                    if (item.Key.Contains(name))
                    {
                        rezervacije[name] += number;
                    }
                }

                if (!rezervacije.Keys.Contains(name))
                {
                    rezervacije.Add(name, number);
                }
               
                Console.WriteLine("Admin has reserved {0} seats for  user {1}!", rezervacije[name], name);
            }

        }
        public static ArrayList GetGroupMembers(string sGroupName)
        {
            ArrayList myItems = new ArrayList();
            GroupPrincipal oGroupPrincipal = GetGroup(sGroupName);

            PrincipalSearchResult<Principal> oPrincipalSearchResult = oGroupPrincipal.GetMembers();

            foreach (Principal oResult in oPrincipalSearchResult)
            {
                myItems.Add(oResult.Name);
            }
            return myItems;
        }

        public static GroupPrincipal GetGroup(string sGroupName)
        {
            PrincipalContext oPrincipalContext = GetPrincipalContext();

            GroupPrincipal oGroupPrincipal = GroupPrincipal.FindByIdentity(oPrincipalContext, sGroupName);
            return oGroupPrincipal;
        }

        public static PrincipalContext GetPrincipalContext()
        {
            PrincipalContext oPrincipalContext = new PrincipalContext(ContextType.Machine);
            return oPrincipalContext;
        }
    }

    }

