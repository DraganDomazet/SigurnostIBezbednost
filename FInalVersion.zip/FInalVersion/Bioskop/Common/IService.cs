﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.Security.Permissions;

namespace Common
{
    [ServiceContract]
    public interface IService
    {

        [OperationContract]
        void AddUser(string username, string password);

        [OperationContract]
        void RemoveUser(string username);

        [OperationContract]
        void Reserve(int number, string kor);

        [OperationContract]
        void ReserveVIPs(int number, string korisnik);

        [OperationContract]
        void DodajVip();

        [OperationContract]
        void RemoveVip();

        [OperationContract]
        void AskForRemoval(string user);

        [OperationContract]
        void AskForVip(string user, string sifra);

        [OperationContract]
        void AddReservation(string name, int num);


    }
}
