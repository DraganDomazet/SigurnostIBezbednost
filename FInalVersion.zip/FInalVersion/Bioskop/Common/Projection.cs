﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    [DataContract]
    public class Projection
    {
        string movie = string.Empty;
        int price = 0;
        int brojSedista = 90;
        int brojVIPSedista = 10;

         Dictionary<string, int> demands = new Dictionary<string, int>();



        /* double VipDiscount = 0;
         DateTime time;*/



        public Projection()
        {

        }

        public Projection(string film, int cena)
        {
            this.movie = film;
            this.price = cena;
        }


        public int Price
        {
            get { return price; }
            set { price = value; }
        }

        public int BrojSedista
        {
            get { return brojSedista; }
            set { brojSedista = value; }
        }

        public int BrojVIPSedista
        {
            get { return brojVIPSedista; }
            set { brojVIPSedista = value; }
        }

        public string Movie
        {
            get { return movie; }
            set { movie = value; }
        }

    }
}
