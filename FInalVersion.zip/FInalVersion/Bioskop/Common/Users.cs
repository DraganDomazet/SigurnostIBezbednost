﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;


namespace Common
{

    [DataContract]
    public class Users
    {
        string username = string.Empty;
        string password = string.Empty;
        int money = GetRandomNumber(500, 3000);
       
        int rez = 0;
        DateTime time;

       public Users()
        {
           
        }
               

        private static readonly Random getrandom = new Random();

        public static int GetRandomNumber(int min, int max)
        {
            lock (getrandom) 
            {
                return getrandom.Next(min, max);
            }
        }
       

        public Users(string _username)
        {
            this.username = _username;
            
        }

        public string Username
        {
            get { return username; }
            set { username = value; }
        }
        
        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        public int Money
        {
            get { return money; }
            set { money = value; }
        }

        public int Rez
        {
            get { return rez; }
            set { rez = value; }
        }

        public DateTime Time
        {
            get { return time; }
            set { time = value; }
        }


    }
}
