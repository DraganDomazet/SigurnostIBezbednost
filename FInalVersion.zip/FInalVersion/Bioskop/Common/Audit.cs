﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace SecurityManager
{
    public class Audit : IDisposable
    {

        private static EventLog customLog = null;
        const string SourceName = "Audit";
        const string LogName = "MyLog";

        static Audit()
        {
            try
            {
                if (!EventLog.SourceExists(SourceName))
                {
                    EventLog.CreateEventSource(SourceName, LogName);
                }

                customLog = new EventLog(LogName, Environment.MachineName, SourceName);
            }
            catch (Exception e)
            {
                customLog = null;
                Console.WriteLine("Error while trying to create log handle. Static constructor Error = {0}", e.Message);
            }
        }

        public static void AccessDenied(string username, string methodName)
        {
            if (customLog != null) //Access denied for user {0} in method {1} due to inadequate privileges.
            {
                String msg = String.Format("AccessDenied for user {0} and method {1}", username, methodName);
                customLog.WriteEntry(msg);
            }
            else
            {
                throw new ArgumentException(string.Format("Error while trying to write event to event log."));
            }

        }

        public static void AccessGranted(string username, string methodName)
        {
            if (customLog != null)     //User {0} successfuly accessed to database executing method {1}.
            {
                String msg = String.Format("AccessGranted for user {0} and method {1}", username, methodName);
                customLog.WriteEntry(msg);
            }
            else
            {
                throw new ArgumentException(string.Format("Error while trying to write event to event log."));
            }

        }

        public static void AthenticationSuccessful (string username)
        {
            if (customLog != null)     //User {0} successfuly accessed to database executing method {1}.
            {
                String msg = String.Format("AthenticationSuccessful for user {0} ", username);
                customLog.WriteEntry(msg);
            }
            else
            {
                throw new ArgumentException(string.Format("Error while trying to write event to event log."));
            }
        }



        public void Dispose()
        {
            if (customLog != null)
            {
                customLog.Dispose();
                customLog = null;
            }
        }
    }
}
