﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using Common;
using System.Security.Permissions;
using System.Security.Principal;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Xml;
using System.Xml.Serialization;
using System.ServiceModel.Description;
using SecurityManager;

namespace SecurityClient
{
    public class Program
    {
        static void Main(string[] args)
        {
            NetTcpBinding binding = new NetTcpBinding();
            string address = "net.tcp://localhost:6500/SecurityService";
            
            Audit.AthenticationSuccessful(Environment.UserName);

            using (ClientProxy proxy = new ClientProxy(binding, address))
            {

                bool flag = true;

                //IsUserInGroup("DESKTOP-FBK9ON1\\admins")
                if (true)
               
                { 

                    do
                    {

                        Console.WriteLine("Menu Selection for ADMINISTRATORS:\n");
                        Console.WriteLine("Press 'a' to add new user");
                        Console.WriteLine("Press 'b' to modify existing user - NOT IMPLEMENTED");
                        Console.WriteLine("Press 'c' for delete existing user!");
                        Console.WriteLine("Press 'd' to approve demands!");
                        Console.WriteLine("Press 'e' to remove VIP members!");
                        Console.WriteLine("Press 'j' to add reservations for user");

                        /*Console.WriteLine("Press 'd' to add projection");
                          Console.WriteLine("Press 'e' to modify projection");
                          Console.WriteLine("Press 'f' to delete projection");*/
                          
                        Console.WriteLine("Menu Selection for Users!\n");
                        Console.WriteLine("Press 'f' to reserve seats!");
                        Console.WriteLine("Press 'g' to ask for VIP membership!");

                        Console.WriteLine("Menu Selection for VIPs:\n");
                        Console.WriteLine("Press 'h' to reserve VIP seats!");
                        Console.WriteLine("Press 'i' to ask for removal from VIP group!");



                        Console.WriteLine("Type 'q' to exit");

                        string option = Console.ReadLine();

                        switch (option)
                        {
                            case "a":
                                Console.WriteLine("Type username: ");
                                string username = Console.ReadLine();
                                Console.WriteLine("Type password: ");
                                string pass = Console.ReadLine();
                                proxy.AddUser(username, pass);
                                break;
                            case "b":
                                break;             
                            case "c":
                                Console.WriteLine("Type username: ");
                                string username1 = Console.ReadLine();
                                proxy.RemoveUser(username1);                                
                                break;
                            case "d":
                                proxy.DodajVip();                                
                                break;
                            case "j":
                                Console.WriteLine("Type username: ");
                                string name = Console.ReadLine();
                                Console.WriteLine("Type number: ");
                                int number = Convert.ToInt32(Console.ReadLine());
                                proxy.AddReservation(name, number);
                                break;
                            case "e":
                                proxy.RemoveVip();
                                break;
                            case "f":
                                Console.WriteLine("Unesi broj mesta koji zelis da rezervises:");
                                int num = Convert.ToInt32(Console.ReadLine());
                                proxy.Reserve(num, Environment.UserName);                                                             
                                break;
                            case "g":
                                Console.WriteLine("Unesite vasu sifru: ");
                                string sifra = Console.ReadLine();
                                proxy.AskForVip(Environment.UserName, sifra);                                
                                break;
                            case "h":
                                Console.WriteLine("Unesi broj mesta koji zelis da rezervises:");
                                int num1 = Convert.ToInt32(Console.ReadLine());
                                string korisnik = Environment.UserName;
                                proxy.ReserveVIPs(num1, korisnik);
                                break;
                            case "i":                                
                                proxy.AskForRemoval(Environment.UserName);
                                break;
                            case "q":
                                Console.Clear();
                                Console.WriteLine("You will now exit the console");
                                flag = false;
                               
                                break;
                            default:
                                Console.Clear();
                                Console.WriteLine("You have not selected an option\nPlease try again\n\n");
                                break;



                        }
                    } while (flag);
             


                }
    

               
            }
        }


    }
}
