﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using Common;


namespace SecurityClient
{
    public class ClientProxy : ChannelFactory<IService>, IService, IDisposable
    {

        IService factory;

        public ClientProxy(NetTcpBinding binding, string address) : base(binding, address)
        {
            factory = this.CreateChannel();
        }

       
        public void AddUser(string username, string password)
        {

            try
            {
                factory.AddUser(username, password);
            }
            catch (Exception e)
            {
                Console.WriteLine("Trenutni korisnik nije admin!  {0}", e.Message);
            }
           
        }

        public void AskForVip(string user, string sifra)
        {
            try
            {
                factory.AskForVip(user, sifra);
            }
            catch (Exception e)
            {
                Console.WriteLine("Trenutni korisnik nije admin!  {0}", e.Message);
            }

        }

        public void AskForRemoval(string user)
        {
            try
            {
                factory.AskForRemoval(user);
            }
            catch (Exception e)
            {
                Console.WriteLine("Trenutni korisnik nije admin!  {0}", e.Message);
            }

        }

        public void DodajVip()
        {
            try
            {
                factory.DodajVip();
            }
            catch (Exception e)
            {
                Console.WriteLine("Trenutni korisnik nije admin!  {0}", e.Message);
            }
        }

        public void RemoveVip()
        {
            try
            {
                factory.RemoveVip();
            }
            catch (Exception e)
            {
                Console.WriteLine("Trenutni korisnik nije admin!  {0}", e.Message);
            }
        }
        public void RemoveUser(string username)
        {

            try
            {
                factory.RemoveUser(username);
            }
            catch (Exception e)
            {
                Console.WriteLine("Trenutni korisnik nije admin!  {0}", e.Message);
            }
        }
        public void Reserve(int number, string kor)
        {

            try
            {
                factory.Reserve(number, kor);
               
            }
            catch (Exception e)
            {
                Console.WriteLine("Trenutni korisnik nije u grupi korisnici!  {0}", e.Message);
            }
           
        }

        public void ReserveVIPs(int number, string kor)
        {

            try
            {
                factory.ReserveVIPs(number, kor);
            }
            catch (Exception e)
            {
                Console.WriteLine("Trenutni korisnik nije u grupi korisnici!  {0}", e.Message);
            }

        }

        

            public void AddReservation(string name, int num)
        {

            try
            {
                factory.AddReservation(name, num);
            }
            catch (Exception e)
            {
                Console.WriteLine("Trenutni korisnik nije u grupi korisnici!  {0}", e.Message);
            }

        }

    }
}
